<?php
/**
 *    OpenSource-SocialNetwork
 *
 * @package   (webbehinds.com).ossn
 * @author    OSSN Core Team <info@opensource-socialnetwork.com>
 * @copyright 2014 Webbehinds
 * @license   General Public Licence http://opensource-socialnetwork.com/licence
 * @link      http://www.opensource-socialnetwork.com/licence
 */




function ossn_arcade_init() {
	ossn_register_page('arcade', 'ossn_arcade_pages');
	  if (ossn_isLoggedin()) {       
		
    	$icon = ossn_site_url('components/OssnPhotos/images/photos-ossn.png');
    	ossn_register_sections_menu('newsfeed', array(
        	'text' => ossn_print('com:ossn:arcade'),
        	'url' => ossn_site_url('arcade'),
        	 'icon' => $icon,
		 'section' => 'games'
	    	));		
    }
}


function ossn_arcade_pages($pages) {

 if (!ossn_isLoggedin()) {
            ossn_error_page();
   }
$title = ossn_print('com:ossn:arcade');
   $contents['content'] = ossn_plugin_view('pages/arcade');
   $content = ossn_set_page_layout('contents', $contents);
   echo ossn_view_page($title, $content);
}

ossn_register_callback('ossn', 'init', 'ossn_arcade_init');
