.menu-section-arcade i:before {
    font-family: FontAwesome;
    content: "\f11b";
}
.menu-section-diablo i:before {
    font-family: FontAwesome;
    content: "\f054";
} 
.menu-section-doomii i:before {
    font-family: FontAwesome;
    content: "\f054";
} 