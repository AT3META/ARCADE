.menu-section-arcade i:before {
    font-family: FontAwesome;
    content: "\f11b";
}