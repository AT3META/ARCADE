<p></p>
<p>DOOM II</p>
<p>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://js-dos.com/games/doom2.exe.html", 
                    "", "width=888, height=666"); 
        } 
    </script>
</p>
<p>
	<iframe src="https://js-dos.com/games/doom2.exe.html" float="left" frameborder="0" scrolling="auto" width="888" height="666" allowfullscreen></iframe></p>
<p></p>
