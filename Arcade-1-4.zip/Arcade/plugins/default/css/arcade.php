.menu-section-arcade i:before {
    font-family: FontAwesome;
    content: "\f11b";
}
.menu-section-item-diablo:before {
    font-family: FontAwesome;
    content: "\f105";
}
.menu-section-item-diabloii:before {
    font-family: FontAwesome;
    content: "\f105";
}
.menu-section-item-doom:before {
    font-family: FontAwesome;
    content: "\f105";
}
.menu-section-item-doomii:before {
    font-family: FontAwesome;
    content: "\f105";
}