<p></p>
<p>DOOM II</p>
<p>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://dos.zone/en/play/https%3A%2F%2Fdoszone-uploads.s3.dualstack.eu-central-1.amazonaws.com%2Foriginal%2F2X%2Fb%2Fb8e702710afd7ded24f03fd2cf40b3c5e1fb0dbf.jsdos?turbo=0&turboRegion=auto", 
                    "", "width=888, height=666"); 
        } 
    </script>
</p>
<p>
	<iframe src="https://dos.zone/en/play/https%3A%2F%2Fdoszone-uploads.s3.dualstack.eu-central-1.amazonaws.com%2Foriginal%2F2X%2Fb%2Fb8e702710afd7ded24f03fd2cf40b3c5e1fb0dbf.jsdos?turbo=0&turboRegion=auto" float="left" frameborder="0" scrolling="auto" width="888" height="666" allowfullscreen></iframe></p>
<p></p>
