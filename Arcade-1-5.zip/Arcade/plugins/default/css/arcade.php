.menu-section-arcade i:before {
    font-family: FontAwesome;
    content: "\f11b";
}
.menu-section-item-diablo:before {
    content: url(<?php echo ossn_site_url('components/Arcade/images/diablo.png');?>) !important;
}
.menu-section-item-diabloii:before {
    content: url(<?php echo ossn_site_url('components/Arcade/images/diabloii.png');?>) !important;
}
.menu-section-item-doom:before {
    content: url(<?php echo ossn_site_url('components/Arcade/images/doom.png');?>) !important;
}
.menu-section-item-doomii:before {
    content: url(<?php echo ossn_site_url('components/Arcade/images/doomii.png');?>) !important;
}