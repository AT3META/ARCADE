<p></p>
<p>DIABLO</p>
<p>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://d07riv.github.io/diabloweb/", 
                    "", "width=888, height=666"); 
        } 
    </script>
</p>
<p>
<div class="icontainer">
  <iframe class="responsive-iframe" src="https://d07riv.github.io/diabloweb/" frameborder="0"></iframe>
</div>
</p>
