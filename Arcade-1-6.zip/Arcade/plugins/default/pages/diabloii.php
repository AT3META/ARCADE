<p></p>
<p>DIABLO II</p>
<p>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://www.projectdiablo2.com/", 
                    "", "width=888, height=666"); 
        } 
    </script>
</p>
<p>
<div class="icontainer">
  <iframe class="responsive-iframe" src="https://www.projectdiablo2.com/" frameborder="0"></iframe>
</div>
</p>
