<iframe
    width="777"
    height="444"
    frameborder="0"
    src="https://hoten.cc/zc/play/"
    allowfullscreen>
</iframe>           
<!--
  Message 'dz-player-exit' will be fired when js-dos is exited:
  
    window.addEventListener("message", (e) => {
        if (e.data.message === "dz-player-exit") {
            // ...
        }
    });
--> 
<p>
	<button class="btn btn-primary" align="center" onclick="NewTab()"> 
    FULLSCREEN 
    </button> 
    <script> 
        function NewTab() { 
            window.open("https://hoten.cc/zc/play/", 
                    "", "width=100%, height=100%"); 
        } 
    </script>
</p>